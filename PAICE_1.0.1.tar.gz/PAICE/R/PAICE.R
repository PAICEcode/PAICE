#' PAICE: Phylogeographic Analysis of Colonization Events
#'
#' PAICE package has three main functions:
#' colonizations, rarecol and maxCol
#'
#' @section Foo functions:
#' The foo functions ...
#'
#' @docType package
#' @name PAICE
NULL
