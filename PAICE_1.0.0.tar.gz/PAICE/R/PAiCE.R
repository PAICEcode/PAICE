#' PAiCE: Phylogeographic Analysis of Colonization Events
#'
#' PAiCE package has three main functions:
#' colonizations, rarecol and maxCol
#'
#' @section Foo functions:
#' The foo functions ...
#'
#' @docType package
#' @name PAICE
NULL
